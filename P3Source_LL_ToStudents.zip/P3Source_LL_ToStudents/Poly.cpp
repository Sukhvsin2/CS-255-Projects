#include "Poly.h"
// ***********************************************
// Shell code provided by Dr. Janet T. Jenkins
// You should comment each method and add
// header comments below these comments
// ***********************************************

Node::Node():coeff(0), degree(0){}
Node::Node(int c, int d):coeff(c), degree(d), next(nullptr){}
Node::Node(int c, int d, Node* n):coeff(c), degree(d), next(n){}
	
	
Poly::Poly():head(nullptr){

}

void Poly::Copy(const Poly& p){

}

Poly::Poly(const Poly& p){
	Copy(p);
}
Poly& Poly::operator= (const Poly& p){
	if (this == &p)
		return *this;
	if (head != nullptr)
		Reset();
	Copy(p);
	return *this;
	
}
Poly::~Poly(){
	Reset();
}
void Poly::AddTerm(int c, int d){
	
}
double Poly::Eval(double x){
    return 0;
}


void Poly::Reset(){
	
}

void Poly::Derivative(){

}

istream& operator>>(istream& is, Poly& p){
	
	return is;
}
ostream& operator<<(ostream& os, const Poly& p){
    
	return os;
}
Poly operator+(const Poly& p1, const Poly& p2){
	Poly result;
	
	return result;
}



